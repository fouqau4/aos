rwrw-- cube 0
